@echo off
REM ============================================================
REM AUDIT (tham dinh): script chi doc log va ghi noi (>>) vao backup.
REM Khong chua lenh del /f /s /q, rd /s, format. Da kiem tra thu cong.
REM ============================================================
set LOG=%~dp0..\data\log-he-thong.log
set OUT=%~dp0..\backup\bao-cao-su-co.txt

if not exist "%LOG%" (
    echo [LOI] Khong tim thay file log: %LOG%
    exit /b 1
)

echo ============================================== >> "%OUT%"
echo    BAO CAO SU CO HE THONG - GREENTECH          >> "%OUT%"
echo    Thoi gian: %date% %time%                    >> "%OUT%"
echo ============================================== >> "%OUT%"

REM Pipe doc tung dong, khong nap ca file 500MB vao RAM
type "%LOG%" | findstr /C:"CRITICAL" /C:"ERROR" /C:"TIMEOUT" >> "%OUT%"

echo ---------------- HET BAO CAO ----------------- >> "%OUT%"
echo Hoan tat. Ket qua: %OUT%
