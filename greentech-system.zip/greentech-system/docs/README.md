# GreenTech System – Quản trị Hạ tầng & Nhật ký Kỹ thuật

Hệ thống tự động lọc log lỗi và đối soát phần cứng 100 trạm cảm biến IoT.

## Cấu trúc thư mục

```text
greentech-system/
├── docs/      README.md, srs-he-thong.docx
├── scripts/   auto_report.bat
├── data/      log-he-thong.log, quan-ly-thiet-bi.xlsx
├── backup/    bao-cao-su-co.txt
└── .env       cấu hình giả định (file ẩn)
```

## Hướng dẫn chạy script

```bat
cd greentech-system\scripts
auto_report.bat
```

Kết quả được nối thêm vào `backup\bao-cao-su-co.txt`.

## Checklist kiểm tra thiết bị

- [x] Tên thư mục dùng kebab-case, không dấu, không khoảng trắng
- [x] Script đã qua bước Audit (không có `del /f /s /q`)
- [ ] Kiểm tra log đầu vào tồn tại trong `data/`
- [ ] Đối soát VLOOKUP không còn lỗi `#N/A`
- [ ] Sao lưu báo cáo vào `backup/`

## Bảng thông số phần cứng

| Mã linh kiện | Thiết bị | Loại storage | Đơn giá (VND) |
|---|---|---|---|
| LK001 | CPU ARM Cortex-A53 | SSD | 450.000 |
| LK002 | CPU ARM Cortex-A72 | SSD | 780.000 |
| LK003 | RAM 2GB | HDD | 150.000 |
| LK004 | RAM 4GB | SSD | 280.000 |
| LK005 | SSD 64GB | SSD | 600.000 |

## Lưu ý

- Mạng Mbps → MB/s: chia 8 (100 Mbps = 12,5 MB/s; log 500MB ≈ 40 giây).
